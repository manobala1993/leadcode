import { LightningElement, api,wire, track } from 'lwc';

export default class IntrestedPartyChild extends LightningElement {
    @api record;
    @api index;
    @track split;
    connectedCallback() {
        this.split = this.record;
        this.ipname = this.split.ipname;
    }
}