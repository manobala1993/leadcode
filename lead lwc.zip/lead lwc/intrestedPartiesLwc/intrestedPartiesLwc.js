import { LightningElement, track, api, wire } from "lwc";
import { CurrentPageReference } from 'lightning/navigation'; 
import { loadStyle } from 'lightning/platformResourceLoader';
import getips from '@salesforce/apex/intrestedpartiescontroller.getSplits';
import loanfeesplits from '@salesforce/resourceUrl/loanfeesplits';

export default class IntrestedPartiesLwc extends LightningElement {
    
    @api recordId;
    @track data = [];
    icon = 'utility:arrowup';
    split = {"Id": "123", "ipname": ""};

    get hasSplit() {
        return (this.data.length > 0);
    }

    connectedCallback() {
        loadStyle(this, loanfeesplits);
       
    }

    init() {
        //this.recordId = (this.recId != undefined)? this.recId : this.recordId;
        //this.recordId = 'a2e780000008OJhAAM';
        console.log(recordId);
        this.loading = true;
        if(!this.recordId) 
        {
            this.recordId = sessionStorage.getItem('recId');
            // window.setTimeout(() => {
            //     location.reload();
            // }, 1000);
            // return;
        }
        
        this.data = [];
        getips({
            recordId: this.recordId
        }).then(response => {
            console.log(response);
            let d = response.ips;
            d.forEach(el => {
                let s = JSON.parse(JSON.stringify(this.split));
                s.Id = el.Id? el.Id : "123", 
                s.ipname = el.Name? el.Name : "";          
                this.data.push(s);
                
            });

          

            this.loading = false;
        }).catch(error => {
            this.loading = false;
            console.error(error);
        });
    }
   
}